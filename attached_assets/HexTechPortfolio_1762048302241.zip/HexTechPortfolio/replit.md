# HEX TECH Portfolio - Replit Configuration

## Overview

HEX TECH is a futuristic digital portfolio showcasing services in 3D product design, web development, and SaaS solutions. The application features an Arcane/Valorant-inspired aesthetic with hexagonal patterns, neon glows, and tech-noir sophistication. It includes a marketing website with multiple pages (Home, What We Do, Projects, Team) and a contact form system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server, configured for fast HMR and optimized production builds
- Wouter for lightweight client-side routing instead of React Router

**UI Component System**
- shadcn/ui component library (New York style variant) providing a comprehensive set of pre-built, accessible components
- Radix UI primitives for headless, accessible component foundations
- Tailwind CSS for utility-first styling with custom design tokens
- CSS variables for theming support (light/dark mode capability)

**Design System**
- Custom color palette with neon accents (cyan, magenta, gold) for futuristic aesthetic
- Hexagonal visual motifs and clip-paths for thematic consistency
- Typography system with display fonts for headers and technical monospace for code
- Glassmorphism effects and neon glow treatments via custom CSS classes
- Spacing primitives following Tailwind's 8px grid system

**State Management**
- TanStack Query (React Query) for server state management and API data fetching
- Local component state with React hooks for UI interactions
- Form handling with React Hook Form and Zod validation

### Backend Architecture

**Server Framework**
- Express.js as the HTTP server with TypeScript
- Custom Vite middleware integration for development mode with HMR
- Static file serving for production builds

**API Design**
- RESTful endpoint pattern (`/api/*` routes)
- Single POST endpoint `/api/contact` for contact form submissions
- Request validation using Zod schemas shared between client and server
- JSON request/response format

**Data Layer**
- Drizzle ORM configured for PostgreSQL database operations
- Schema-first approach with TypeScript type inference
- In-memory storage implementation (MemStorage class) for development/fallback
- Database schema includes users table and contact_messages table

**Session & State**
- Stateless API design for contact submissions
- Future authentication capability via users schema
- Session management prepared with connect-pg-simple for PostgreSQL-backed sessions

### External Dependencies

**Database**
- PostgreSQL via Neon serverless driver (`@neondatabase/serverless`)
- Drizzle ORM (`drizzle-orm`) for type-safe database queries
- Drizzle Kit for schema migrations and database push operations
- Connection via `DATABASE_URL` environment variable

**UI Libraries**
- Radix UI component primitives (19+ component packages for dialogs, dropdowns, menus, etc.)
- Embla Carousel for carousel/slider functionality
- Lucide React for icon system
- class-variance-authority (CVA) for component variant management

**Form & Validation**
- React Hook Form with Hookform Resolvers for form state management
- Zod for runtime schema validation
- drizzle-zod for automatic schema generation from database models

**Utilities**
- date-fns for date manipulation and formatting
- clsx and tailwind-merge for conditional class name composition
- nanoid for unique ID generation

**Development Tools**
- Replit-specific Vite plugins for error overlay, cartographer, and dev banner
- tsx for TypeScript execution in development
- esbuild for production server bundling

**Asset Management**
- Custom Vite alias configuration for assets (`@assets` path)
- Static image imports from `attached_assets/generated_images` directory
- Background images integrated into hero sections

### Architecture Decisions

**Monorepo Structure**
- Unified TypeScript configuration across client, server, and shared code
- Shared schema definitions in `/shared` directory consumed by both frontend and backend
- Path aliases (`@/`, `@shared/`, `@assets/`) for clean imports

**Type Safety**
- End-to-end TypeScript with strict mode enabled
- Shared Zod schemas ensure type consistency between API contracts and database models
- Drizzle ORM provides compile-time type safety for database queries

**Development Experience**
- Vite's fast HMR for instant feedback during UI development
- TSX for running TypeScript directly in Node.js during development
- Custom logging middleware for API request tracking

**Production Build**
- Separate client (Vite) and server (esbuild) build processes
- Client builds to `dist/public`, server to `dist/index.js`
- Static asset optimization through Vite's build pipeline

**Styling Approach**
- Utility-first with Tailwind CSS for rapid development
- CSS variables for runtime theming without JavaScript
- Component-scoped variants via CVA for maintainable component APIs
- Custom utility classes for neon effects and glassmorphism

**Contact Form Flow**
- Client-side validation with Zod schema before submission
- Mutation hooks via TanStack Query for optimistic UI and error handling
- Toast notifications for user feedback
- Server-side validation as defense-in-depth
- Persistent storage in PostgreSQL (or in-memory fallback)