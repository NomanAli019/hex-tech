# Hex Tech Portfolio - Design Guidelines

## Design Approach: Reference-Based with Thematic Integration

**Primary References:**
- Nova.app: Smooth scroll animations, elegant transitions, premium feel
- Theatre.js: Cinematic motion design, sophisticated choreography
- Richard Mattka Prototypes: Interactive 3D elements, experimental layouts

**Thematic Direction:**
Arcane/Valorant-inspired futuristic aesthetic with hexagonal patterns, neon glows, and tech-noir sophistication. The design should feel like a high-tech agency from the Arcane universe.

## Typography

**Font System:**
- Primary Display: "Tungsten" or "Druk Wide" style (bold, condensed, geometric) for headers - capturing Valorant's aggressive typography
- Secondary: "Inter" or "Space Grotesk" for body text - clean, technical, readable
- Accent: Monospace font (e.g., "JetBrains Mono") for technical details and code snippets

**Hierarchy:**
- Hero Headlines: 4xl to 6xl, bold, letter-spacing tight (-0.02em)
- Section Headers: 3xl to 4xl, semibold
- Subsections: xl to 2xl, medium
- Body Text: base to lg, regular (leading-relaxed for readability)
- Captions/Labels: sm, uppercase, tracked-wider

## Layout System

**Spacing Primitives:**
Primary units: 2, 4, 8, 12, 16, 20, 24, 32 (Tailwind scale)
- Component padding: p-8, p-12, p-16
- Section spacing: py-20, py-24, py-32
- Grid gaps: gap-4, gap-8, gap-12

**Container Strategy:**
- Full-bleed sections with inner max-w-7xl containers
- Asymmetric layouts with 60/40 or 70/30 splits
- Bleeding content: Some elements intentionally overflow containers for visual interest

## Visual Treatment

**Neon/Glow Effects:**
- Primary neon: Cyan (#00D9FF) with outer glow
- Secondary neon: Magenta (#FF0080) for accents
- Tertiary: Gold (#FFD700) for premium highlights
- Hextech signature: Layered glows (box-shadow: 0 0 20px, 0 0 40px, 0 0 60px)

**Hexagonal Patterns:**
- Background texture: Subtle hexagon grid pattern (10% opacity)
- Section dividers: Hexagonal clip-paths
- Cards/Components: Hexagon corner accents or borders
- Icons: Hexagonal containers with gradient fills

**Gradient Applications:**
- Hero overlays: Dark to transparent gradients
- Cards: Subtle radial gradients from center
- Borders: Animated gradient borders on interactive elements

## Component Library

**Navigation:**
- Fixed header with glass-morphism effect (backdrop-blur-lg, bg-opacity-80)
- Logo: "HEX TECH" in geometric display font with subtle neon underline
- Menu items: Uppercase, tracked-wide, hover reveals neon underline animation
- Mobile: Full-screen overlay with staggered item animations

**Hero Section (Home):**
- Full viewport height (min-h-screen)
- Large background image: Futuristic tech environment with hexagonal overlays
- Animated 3D element or particle system (using Three.js/React Three Fiber)
- Headline with glitch effect on load
- CTA buttons with blurred backgrounds and neon borders

**Service Cards (Home):**
- Grid layout: 3 columns on desktop, stacked on mobile
- Each card: Hexagonal icon container, title, description, "Learn More" link
- Hover: Lift effect (translateY) with enhanced glow
- Services: 3D Product Design, Web Development (mention tech stack flexibility), SaaS Products

**Product Showcase (Home):**
- Split layout: Image/mockup on one side, content on other
- Clashey: Feature list with checkmarks, scope description, CTA
- Office Boy: Similar treatment with differentiated accent color
- Alternating left/right layout for visual rhythm

**What We Do Page:**
- Hero: Bold typographic statement with animated background
- Deep-dive sections: Each service gets expansive treatment
- Tech Stack visualization: Animated icons/logos with connecting lines
- Capabilities matrix: Grid showing expertise areas
- Interactive elements: Hover-triggered expandable details

**Projects Showcase:**
- Masonry grid or Bento box layout (varied sizes)
- Project cards: Placeholder images with overlay on hover
- Overlay content: Project name, category, brief description
- Filters: Category tags with smooth transitions
- Lightbox/modal: Click to expand with full project details

**Team Page:**
- Horizontal scroller with snap-scroll behavior
- Team cards: Portrait placeholder, name, role, bio snippet
- Neon frame effect: Animated border that pulses/rotates
- Parallax: Cards move at different speeds during scroll
- Background: Animated hexagonal particle system

**Footer:**
- Three-column layout: Contact form (left 50%), Info (right 25%), Social (right 25%)
- Contact form: Name, email, message fields with neon focus states
- Location: Johar Town, Lahore, Pakistan with map icon
- Contact: +923052253482, nomanromeo694@gmail.com
- Background: Dark with subtle hexagon texture

## Animations & Interactions

**Scroll Animations:**
- Parallax scrolling: Background elements move slower than foreground
- Fade-in-up: Elements enter from bottom with opacity transition
- Stagger: Sequential reveal of grid items (0.1s delay between each)

**Micro-Interactions:**
- Button hovers: Glow intensifies, slight scale (1.05)
- Card hovers: Lift (translateY -8px), shadow enhancement
- Link hovers: Neon underline sweep from left to right
- Page transitions: Smooth fade with slight scale

**Hero Animations:**
- Typewriter effect for headline reveal
- Floating/orbiting 3D elements
- Particle trails following cursor (optional subtle effect)

**Team Scroller:**
- Smooth horizontal scroll with momentum
- Auto-play option with pause on hover
- Neon trail effect following active card

## Images

**Hero Image (Home):**
Large full-bleed background image showing futuristic tech workspace, circuit boards, or abstract hexagonal patterns with dark cyan/magenta lighting. Should convey innovation and technical expertise.

**Service Section Icons:**
Geometric, line-art style icons in hexagonal frames showing 3D modeling, code brackets, and SaaS symbols.

**Project Placeholders:**
Gray rectangles with hexagonal corner accents and centered "Project Image" text. Aspect ratio: 16:9 or 4:3 depending on layout.

**Team Photos:**
Circular or hexagonal portrait placeholders with gradient borders and subtle glow effects.

## Responsive Considerations

- Desktop (1280px+): Full multi-column layouts, expansive spacing
- Tablet (768-1279px): Reduce to 2 columns, adjust spacing to py-16
- Mobile (<768px): Single column stacks, py-12 spacing, touch-friendly targets (min 44px)