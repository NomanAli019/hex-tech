import ProductsSection from '../ProductsSection';

export default function ProductsSectionExample() {
  return <ProductsSection />;
}
